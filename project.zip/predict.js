// Predict enrollment based on stored selections and CSV data
const CSV_PATH = 'data.csv';
let chartInstance = null;

function getSelectionsFromForm() {
    const academicYearSelect = document.getElementById('academicYear');
    const departmentSelect = document.getElementById('department');
    return {
        selectedYear: (academicYearSelect?.value || '').trim(),
        selectedDepartment: (departmentSelect?.value || '').trim()
    };
}

function updateSelectionText({ selectedYear, selectedDepartment }) {
    const yearEl = document.getElementById('resultYear');
    const deptEl = document.getElementById('resultCourse');
    if (yearEl) yearEl.textContent = selectedYear || '—';
    if (deptEl) deptEl.textContent = selectedDepartment || '—';
}

function setResultValue(text) {
    const valueEl = document.getElementById('resultValue');
    if (valueEl) valueEl.textContent = text;
}

function toggleResults(show) {
    const section = document.getElementById('resultsSection');
    if (!section) return;
    section.classList.toggle('hidden', !show);
}

function buildChart(departmentRows) {
    const canvas = document.getElementById('predictionChart');
    if (!canvas || typeof Chart === 'undefined') return;

    const labelsAndValues = departmentRows
        .map(row => ({ year: parseInt(row.Year, 10), value: parseInt(row.Predicted_Enrollment, 10) }))
        .filter(item => !Number.isNaN(item.year) && !Number.isNaN(item.value))
        .sort((a, b) => a.year - b.year);

    if (chartInstance) {
        chartInstance.destroy();
    }

    chartInstance = new Chart(canvas.getContext('2d'), {
        type: 'line',
        data: {
            labels: labelsAndValues.map(item => item.year),
            datasets: [{
                label: 'Predicted Enrollment',
                data: labelsAndValues.map(item => item.value),
                borderColor: '#0f766e',
                backgroundColor: 'rgba(15,118,110,0.15)',
                tension: 0.25,
                pointRadius: 4,
                pointBackgroundColor: '#0f766e',
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false },
                tooltip: { mode: 'index', intersect: false }
            },
            scales: {
                y: { beginAtZero: true, ticks: { precision: 0 } },
                x: { grid: { display: false } }
            }
        }
    });
}

function renderPrediction(rows, selections) {
    const { selectedYear, selectedDepartment } = selections;
    if (!selectedYear || !selectedDepartment) {
        setResultValue('Pick an academic year and department to see predictions.');
        toggleResults(true);
        return;
    }

    const targetDept = selectedDepartment.toLowerCase();
    const targetYear = selectedYear.trim();

    // Support both tall format (Department,Year,Predicted_Enrollment) and wide format (Predicted_2026, Predicted_2027, Predicted_2028)
    const cleanedRows = rows.map(row => {
        const dept = (row.Department || '').trim();
        if (row.Year !== undefined && row.Predicted_Enrollment !== undefined) {
            return [{
                Department: dept,
                Year: (row.Year || '').toString().trim(),
                Predicted_Enrollment: (row.Predicted_Enrollment || '').toString().trim()
            }];
        }

        const entries = [];
        const wideKeys = [
            { key: 'Predicted_2026', year: '2026' },
            { key: 'Predicted_2027', year: '2027' },
            { key: 'Predicted_2028', year: '2028' }
        ];
        wideKeys.forEach(({ key, year }) => {
            if (row[key] !== undefined) {
                entries.push({
                    Department: dept,
                    Year: year,
                    Predicted_Enrollment: (row[key] || '').toString().trim()
                });
            }
        });
        return entries;
    }).flat();

    const departmentRows = cleanedRows.filter(r => r.Department.toLowerCase() === targetDept);
    const match = departmentRows.find(r => r.Year === targetYear);

    if (match && match.Predicted_Enrollment) {
        setResultValue(`${match.Predicted_Enrollment} Students`);
    } else {
        setResultValue('No prediction data available.');
    }

    toggleResults(true);
    buildChart(departmentRows);
}

function loadCsvAndRender(selections) {
    setResultValue('Loading prediction...');
    toggleResults(true);
    Papa.parse(CSV_PATH, {
        download: true,
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
            const rows = Array.isArray(results.data) ? results.data : [];
            renderPrediction(rows, selections);
        },
        error: () => {
            setResultValue('No prediction data available.');
            toggleResults(true);
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    const academicYearSelect = document.getElementById('academicYear');
    const departmentSelect = document.getElementById('department');
    const generateButton = document.getElementById('generatePrediction');

    const handlePredict = () => {
        const selections = getSelectionsFromForm();
        updateSelectionText(selections);
        loadCsvAndRender(selections);
    };

    generateButton?.addEventListener('click', handlePredict);
    academicYearSelect?.addEventListener('change', () => {
        if (!document.body.classList.contains('auto-preview')) return;
        handlePredict();
    });
    departmentSelect?.addEventListener('change', () => {
        if (!document.body.classList.contains('auto-preview')) return;
        handlePredict();
    });

    // Optional: auto preview on load using defaults
    handlePredict();
});
